<?php

namespace Cloudinary;

/**
 * Class Error
 * @package Cloudinary
 */
class Error extends \Exception
{
}
