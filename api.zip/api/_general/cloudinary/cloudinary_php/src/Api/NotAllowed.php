<?php

namespace Cloudinary\Api;

/**
 * Class NotAllowed
 * @package Cloudinary\Api
 */
class NotAllowed extends Error
{
}
